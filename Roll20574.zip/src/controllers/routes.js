const express = require('express');
const router = express.Router();




router.get('/login', (req, res) => {
  res.render('loign routes');
});











module.exports = router;